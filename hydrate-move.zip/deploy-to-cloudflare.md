# Cloudflare Pages 部署指南

## 当前环境限制
- Node.js版本：v18.16.0（需要v20.0.0+）
- 建议使用手动部署方式

## 部署方法

### 方法1：手动上传（推荐）
1. 访问：https://dash.cloudflare.com/58213c02ef32bb1dba9214ebea647bec/pages
2. 点击"Create a project"
3. 选择"Upload assets"
4. 拖拽整个项目文件夹或选择文件
5. 项目名：hydrate-move
6. 部署完成

### 方法2：使用wrangler（需要Node.js v20+）
如果升级Node.js后：

```bash
# 安装wrangler
npm install -g wrangler

# 登录
wrangler login

# 创建项目
wrangler pages project create hydrate-move

# 部署
wrangler pages deploy . --project-name=hydrate-move
```

### 方法3：GitHub集成（可选）
1. 在Cloudflare Pages创建项目
2. 选择"Connect to Git"
3. 连接GitHub仓库
4. 自动部署

## 部署验证
部署完成后访问：
- `https://hydrate-move.pages.dev`（默认域名）
- 或自定义域名

## 优势
- ✅ 国内访问稳定
- ✅ 完全免费
- ✅ 无需备案
- ✅ 全球CDN加速