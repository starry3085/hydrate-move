# Node.js升级与Cloudflare自动部署指南

## 🚨 Node.js版本问题
当前版本：v18.16.0  →  需要：v20.0.0+

## 🔄 安全升级方案

### 方案1：nvm-windows（推荐）
```bash
# 1. 下载nvm-windows
# https://github.com/coreybutler/nvm-windows/releases/latest
# 下载 nvm-setup.exe 并安装

# 2. 安装Node.js 20
nvm install 20.18.0
nvm use 20.18.0

# 3. 验证
node --version  # 应显示 v20.18.0
npm --version   # 应显示 10.x.x
```

### 方案2：直接升级
1. 访问：https://nodejs.org/
2. 下载LTS版本（推荐20.x.x）
3. 直接覆盖安装
4. 重启终端/IDE

## 🎯 兼容性检查
升级后运行以下命令确保无冲突：
```bash
# 检查项目依赖
npm audit
npm run start  # 本地测试

# 检查Cloudflare部署
npm run deploy:cf-direct
```

## 🚀 自动部署配置

### 升级后使用wrangler
```bash
# 登录Cloudflare（升级后执行）
npx wrangler login

# 创建Pages项目
npx wrangler pages project create hydrate-move

# 一键部署
npm run deploy:cf-direct
```

### 当前可用方案（无需升级）
```bash
# 使用兼容版本部署
npm run deploy:cf
```

## 📋 部署命令汇总

| 命令 | 描述 | 状态 |
|------|------|------|
| `npm run start` | 本地开发 | ✅ 可用 |
| `npm run deploy` | GitHub Pages | ✅ 可用 |
| `npm run deploy:cf` | Cloudflare自动部署 | ✅ 可用 |
| `npm run deploy:cf-direct` | 直接wrangler部署 | ⚠️ 需Node 20+ |

## 🔧 快速开始

### 立即部署（无需升级）
1. 手动上传：https://dash.cloudflare.com/58213c02ef32bb1dba9214ebea647bec/pages
2. 或使用：npm run deploy:cf

### 升级后自动部署
1. 升级Node.js到20+
2. npx wrangler login
3. npm run deploy:cf-direct

## ✅ 升级验证清单
- [ ] Node.js版本显示20.x.x
- [ ] 项目本地运行正常
- [ ] Cloudflare部署成功
- [ ] 访问：https://hydrate-move.pages.dev