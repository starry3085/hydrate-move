#!/usr/bin/env node

/**
 * 自动部署脚本 - Cloudflare Pages
 * 使用Wrangler CLI自动部署到Cloudflare Pages
 */

const { execSync } = require('child_process');
const fs = require('fs');

console.log('🚀 开始自动部署到Cloudflare Pages...');

try {
  // 检查Node.js版本
  const nodeVersion = process.version;
  console.log(`当前Node.js版本: ${nodeVersion}`);
  
  if (parseInt(nodeVersion.slice(1).split('.')[0]) < 20) {
    console.warn('⚠️ 建议升级到Node.js 20+以获得最佳体验');
    console.log('执行: npx wrangler@latest pages deploy . --project-name=hydrate-move');
  }

  // 检查wrangler配置
  if (!fs.existsSync('wrangler.toml')) {
    console.error('❌ 缺少wrangler.toml配置文件');
    process.exit(1);
  }

  // 部署命令
  const deployCommand = 'npx wrangler@latest pages deploy . --project-name=hydrate-move';
  
  console.log('📦 正在部署...');
  execSync(deployCommand, { stdio: 'inherit' });
  
  console.log('✅ 部署完成！');
  console.log('访问: https://hydrate-move.pages.dev');

} catch (error) {
  console.error('❌ 部署失败:', error.message);
  console.log('请检查: 1) Cloudflare账号是否登录 2) 项目是否存在');
}