// Simple version control
window.APP_VERSION = '1.0.2';
console.log('Hydrate Move v' + window.APP_VERSION + ' - Feedback Feature Update');